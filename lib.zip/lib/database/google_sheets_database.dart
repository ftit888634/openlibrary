import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:random_string/random_string.dart';

class GoogleSheetsDatabase {
  String api(path, method, id) {
    //please don't use this api it's only for testing our projects.
    final url =
        "https://script.google.com/macros/s/AKfycbyjcnPm5ZNptGD6Q1PZW9wExwlS125oJOdi9BAIyVJAM50RxcE34Imy2NOBLsTBC5xdIQ/exec?sheet=$path&method=$method&id=$id";
    return url;
  }

  static post(path, data) async {
    var id = '';
    await http.post(
      Uri.parse(GoogleSheetsDatabase().api(path, 'post', id)),
      body: json.encode(data),
    );
  }

  static update(path, id, data) async {
    await http.post(
      Uri.parse(GoogleSheetsDatabase().api(path, 'update', id)),
      body: json.encode(data),
    );
  }

  static delete(path, id) async {
    await http.get(
      Uri.parse(GoogleSheetsDatabase().api(path, 'delete', id)),
    );
  }

  static get(path, id) async {
    var response = await http.get(
      Uri.parse(GoogleSheetsDatabase().api(path, 'get', id)),
    );
    return json.decode(response.body);
  }

  static send_email(to, subject, body1, from, replayTo, url) async {
    await http.post(
      Uri.parse('$url/database.php?path=users/send_email/'),
      body: json.encode({
        'to': to,
        'subject': subject,
        'body': body1,
        'from': from,
        'replayTo': replayTo
      }),
    );
  }
}
