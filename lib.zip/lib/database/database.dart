// ignore_for_file: unnecessary_null_comparison, non_constant_identifier_names

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class Db {
  String api(path, method, id) {
    final Api = 'https://fataahit.000webhostapp.com/database.php?path=${path}/$method/$id';
    return Api;
  }
  var dir = 'https://wehelapp.com/';

  static uploadFile(fileName, userId, userFile, fileType) async {
    final result =
        await http.post(Uri.parse(Db().api('users', 'upload_file', '')),
            body: json.encode(<String, dynamic>{
              'file_name': fileName,
              'user_id': userId,
              'file_type': fileType,
              'user_file': base64.encode(userFile),
            }));
  }

  static delete_file(file, id) async {
    var fileName = file.split('/').last;
    await http.post(Uri.parse(Db().api('users', 'delete_file', id)),
        body: json.encode(<String, Object>{
          'path': 'uploads/users/$id/$fileName',
        }));
  }

  // static download_file(String url) async {
  //   Dio dio = Dio();
  //   if (await Permission.storage.request().isGranted) {
  //     EasyLoading.show(status: 'Downloading...');
  //     var name = url.split('/').last;
  //     try {
  //       if (Platform.isAndroid) {
  //         dio.download(
  //             url, "/storage/emulated/0/Download/name${randomNumeric(6)}.pdf");
  //         EasyLoading.showSuccess('File Downloaded');
  //       } else if (Platform.isIOS) {
  //         dio.download(url,
  //             "${(await getApplicationDocumentsDirectory()).path}/name${randomNumeric(6)}.pdf");
  //         EasyLoading.showSuccess('File Downloaded');
  //       }
  //     } catch (e) {
  //       EasyLoading.showError(e.toString());
  //       print(e.toString());
  //     }
  //   } else {
  //     EasyLoading.showError('Permission Denied');
  //     Map<Permission, PermissionStatus> statuses = await [
  //       Permission.storage,
  //     ].request();
  //   }
  // }

  static post(path, data) async {
    var id = '';
    await http.post(
      Uri.parse(Db().api(path, 'post', id)),
      body: json.encode(data),
    );
  }

  static send_email(to, subject, body1, from, replayTo) async {
    await http.post(
      Uri.parse(Db().api('users', 'send_email', 'id')),
      body: json.encode({
        'to': to,
        'subject': subject,
        'body': body1,
        'from': from,
        'replayTo':replayTo
      }),
    );
  }

  static put(path, id, data) async {
    await http.post(
      Uri.parse(Db().api(path, 'put', id)),
      body: json.encode(data),
    );
  }

  static update(path, id, data) async {
    await http.post(
      Uri.parse(Db().api(path, 'patch', id)),
      body: json.encode(data),
    );
  }

  static delete(path, id) async {
    var data = [];
    await http.post(
      Uri.parse(Db().api(path, 'delete', id)),
      body: json.encode(data),
    );
  }

  static get(path, id) async {
    var response = await http.post(
      Uri.parse(Db().api(path, 'get', id)),
    );
    return json.decode(response.body);
  }
}
