// ignore_for_file: unnecessary_null_comparison, non_constant_identifier_names

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:random_string/random_string.dart';

class OFFDB {
  static get(path,id) async {
    var d = {path: []};
    String dir = Platform.isAndroid
        ? "/storage/emulated/0/Download/"
        : (await getApplicationDocumentsDirectory()).path;
    var file = File('$dir/database.exe');
    if (await file.exists()) {
      var data = await file.readAsString();
      final body = await json.decode(data);
      List el = body[path];
      if(id.isEmpty){
        return el;
      }else{
      var byId = el.firstWhere((u) => u['id'] == id);
        return byId;
      }
    } else {
      var string = json.encode(d);
      file.writeAsString(string);
    }
  }

  static update(path, id, element) async {
    String dir = Platform.isAndroid
        ? "/storage/emulated/0/Download/"
        : (await getApplicationDocumentsDirectory()).path;
    var file = File('$dir/database.exe');
      var d = await file.readAsString();
      final body =  json.decode(d);
      List el = body[path];
      Map cur = el.firstWhere((u) => u['id'] == id);
      el.remove(cur);
      el.add(element);
      body[path] = el;
      var body1 = json.encode(body);
      await file.writeAsString(body1);
      print(body);
  }
  static post(path,element)async{
    String dir = Platform.isAndroid
        ? "/storage/emulated/0/Download/"
        : (await getApplicationDocumentsDirectory()).path;
    var file = File('$dir/database.exe');
    if (await file.exists()) {
      var d = await file.readAsString();
      final body =  json.decode(d);
      List el = body[path];
      el.add(element);
      body[path] = el;
      var body1 = json.encode(body);
      await file.writeAsString(body1);
      print(body1);
    }else{
      var b = {path: []};
      var string = json.encode(b);
      file.writeAsString(string);
      var d = await file.readAsString();
      final body =  json.decode(d);
      List el = body[path];
      el.add(element);
      body[path] = el;
      var body1 = json.encode(body);
      await file.writeAsString(body1);
    }
  }
  static delete(path,id)async{
    String dir = Platform.isAndroid
        ? "/storage/emulated/0/Download/"
        : (await getApplicationDocumentsDirectory()).path;
    var file = File('$dir/database.exe');
      var d = await file.readAsString();
      final body =  json.decode(d);
      List el = body[path];
      Map cur = el.firstWhere((u) => u['id'] == id);
      el.remove(cur);
      body[path] = el;
      var body1 = json.encode(body);
      await file.writeAsString(body1);
      print(body);
  }
}