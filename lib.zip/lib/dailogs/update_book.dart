  import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import '../database/google_sheets_database.dart';
import '../widgets/custom_text.dart';
import '../widgets/flat_button.dart';

Future<dynamic> updateBook(BuildContext context, book) {
    return showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            var height = MediaQuery.of(context).size.height;
                            var width = MediaQuery.of(context).size.width;
                            TextEditingController nameController =
                                TextEditingController(
                                    text: book['name'].toString());
                            TextEditingController linkController =
                                TextEditingController(
                                    text: book['link'].toString());
                            TextEditingController downloadLinkController =
                                TextEditingController(
                                    text: book['downloadLink'].toString());
                            TextEditingController imageController =
                                TextEditingController(
                                    text: book['image'].toString());
                            TextEditingController descriptionController =
                                TextEditingController(
                                    text: book['description'].toString());
                            return StatefulBuilder(
                              builder: (BuildContext context,
                                  void Function(void Function()) setState) {
                                return AlertDialog(
                                  title: Container(
                                    width: double.infinity,
                                    height: 50,
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).primaryColor,
                                    ),
                                    child: Center(
                                      child: CustomText(
                                          text: "Edit Book",
                                          fontFamily: 'MerriWeather',
                                          textColor: Colors.white,
                                          fontWeight: FontWeight.w800,
                                          fontStyle: FontStyle.normal,
                                          fontSize: height * 0.02),
                                    ),
                                  ),
                                  content: SingleChildScrollView(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        TextFormField(
                                          decoration: InputDecoration(
                                              label: Text('book name')),
                                          controller: nameController,
                                        ),
                                        TextFormField(
                                          decoration: InputDecoration(
                                              label: Text('book link')),
                                          controller: linkController,
                                        ),
                                        TextFormField(
                                          decoration: InputDecoration(
                                              label: Text('downloadLink')),
                                          controller: downloadLinkController,
                                        ),
                                        TextFormField(
                                          decoration: InputDecoration(
                                              label: Text('image link')),
                                          controller: imageController,
                                        ),
                                        TextFormField(
                                          decoration: InputDecoration(
                                              label: Text('book description')),
                                          controller: descriptionController,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            FlatButton(
                                              backgroundColor:
                                                  Theme.of(context).primaryColor,
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                              buttonText: 'Update',
                                              textColor: Colors.white,
                                              fontWeight: FontWeight.w400,
                                              fontStyle: FontStyle.normal,
                                              height: 50,
                          width: width * 0.3,
                                              onTap: () async {
                                                EasyLoading.show(
                                                    status: 'Please wait...');
                                                try {
                                                  await GoogleSheetsDatabase.update(
                                                      'books',
                                                      book['id'].toString(), {
                                                    'name': nameController.text,
                                                    'image': imageController.text,
                                                    'link': linkController.text,
                                                    'downloadLink':
                                                        downloadLinkController.text,
                                                    'description':
                                                        descriptionController.text,
                                                  });
                                                  Navigator.pop(context);
                                                  EasyLoading.showSuccess(
                                                      'book updated');
                                                } catch (e) {
                                                  EasyLoading.showError(
                                                      e.toString());
                                                }
                                              },
                                            ),

                                            FlatButton(
                                          backgroundColor:
                                              Theme.of(context).primaryColor,
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          buttonText: 'Delete',
                                          textColor: Colors.white,
                                          fontWeight: FontWeight.w400,
                                          fontStyle: FontStyle.normal,
                                          height: 50,
                          width: width * 0.3,
                                          onTap: () async {
                                            EasyLoading.show(
                                                status: 'Please wait...');
                                            try {
                                              await GoogleSheetsDatabase.delete(
                                                  'books',
                                                  book['id'].toString());
                                              Navigator.pop(context);
                                              EasyLoading.showSuccess(
                                                  'book deleted');
                                            } catch (e) {
                                              EasyLoading.showError(
                                                  e.toString());
                                            }
                                          },
                                        ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        );
  }