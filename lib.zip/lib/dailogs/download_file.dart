import 'dart:io';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:random_string/random_string.dart';

Future<void> downloadFile(String url, String filename) async {
  final dir = await getApplicationDocumentsDirectory();
  final file = File(Platform.isAndroid ? "/storage/emulated/0/Download/books/${randomNumeric(6)}$filename.pdf" : '${dir.path}/$filename${randomNumeric(6)}.pdf');
  EasyLoading.show(status: 'downloading....');
  final response = await http.get(Uri.parse(url));
  await file.writeAsBytes(response.bodyBytes);
  EasyLoading.showSuccess('File downloaded to: ${file.path}');
}
