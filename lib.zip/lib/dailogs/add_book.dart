import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:random_string/random_string.dart';

import '../database/google_sheets_database.dart';
import '../widgets/custom_text.dart';
import '../widgets/flat_button.dart';

Future<dynamic> addBook(BuildContext context) {
  return showDialog(
    context: context,
    builder: (BuildContext context) {
      var height = MediaQuery.of(context).size.height;
      var width = MediaQuery.of(context).size.width;
      TextEditingController nameController = TextEditingController();
      TextEditingController linkController = TextEditingController();
      TextEditingController downloadLinkController = TextEditingController();
      TextEditingController imageController = TextEditingController();
      TextEditingController descriptionController = TextEditingController();
      return StatefulBuilder(
        builder:
            (BuildContext context, void Function(void Function()) setState) {
          return AlertDialog(
            title: Container(
              width: double.infinity,
              height: 50,
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
              ),
              child: Center(
                child: CustomText(
                    text: "Add Book",
                    fontFamily: 'MerriWeather',
                    textColor: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontStyle: FontStyle.normal,
                    fontSize: height * 0.02),
              ),
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    decoration: InputDecoration(label: Text('book name')),
                    controller: nameController,
                  ),
                  TextFormField(
                    decoration: InputDecoration(label: Text('bookId from drive')),
                    controller: linkController,
                  ),
                  TextFormField(
                    decoration: InputDecoration(label: Text('bookId from drive')),
                    controller: downloadLinkController,
                  ),
                  TextFormField(
                    decoration: InputDecoration(label: Text('image link')),
                    controller: imageController,
                  ),
                  TextFormField(
                    decoration: InputDecoration(label: Text('book description')),
                    controller: descriptionController,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  FlatButton(
                    backgroundColor: Theme.of(context).primaryColor,
                    borderRadius: BorderRadius.circular(8.0),
                    buttonText: 'Save',
                    textColor: Colors.white,
                    fontWeight: FontWeight.w400,
                    fontStyle: FontStyle.normal,
                    height: 50,
                    width: width,
                    onTap: () async {
                      EasyLoading.show(status: 'Please wait...');
                      try {
                        await GoogleSheetsDatabase.post('books', {
                          'id': randomAlphaNumeric(20),
                          'name': nameController.text,
                          'image': imageController.text,
                          'link':
                              "https://drive.google.com/file/d/${linkController.text}/preview",
                          'downloadLink':
                              "https://drive.google.com/uc?export=download&id=${downloadLinkController.text}",
                          'description': descriptionController.text,
                        });
                        Navigator.pop(context);
                        EasyLoading.showSuccess('book added');
                      } catch (e) {
                        EasyLoading.showError(e.toString());
                      }
                    },
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}
