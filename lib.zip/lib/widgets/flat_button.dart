import 'package:flutter/material.dart';

import 'custom_text.dart';

class FlatButton extends StatelessWidget {
  final Color backgroundColor;
  final BorderRadius borderRadius;
  final String buttonText;
  final fontFamily;
  final fontSize;
  final double height;
  final Function() onTap;
  final double width;
  final Color textColor;
  final FontWeight fontWeight;
  final FontStyle fontStyle;
  const FlatButton(
      {super.key,
      required this.backgroundColor,
      required this.borderRadius,
      required this.buttonText,
      required this.textColor,
      required this.fontWeight,
      required this.fontStyle,
      required this.height,
      required this.width, this.fontFamily, this.fontSize, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: borderRadius,
        ),
        child: Center(
          child: CustomText(
            fontFamily: fontFamily,
              text: buttonText,
              textColor: textColor,
              fontSize: fontSize,
              fontWeight: fontWeight,
              fontStyle: fontStyle),
        ),
      ),
    );
  }
}
