import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

class BooksView extends StatefulWidget {
  final String link;
  final String name;
  final String type;
  const BooksView({super.key, required this.link, required this.name, required this.type});

  @override
  State<BooksView> createState() => _BooksViewState();
}

class _BooksViewState extends State<BooksView> {
  GlobalKey<ScaffoldState> scaffoldState = GlobalKey();
  WebViewController controller = WebViewController();
  int progress = 0;
  @override
  void initState() {
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.link));
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    super.dispose();
  }

  int _progress = 0;
  @override
  Widget build(BuildContext context) {
    return OrientationBuilder(builder: (context, orientation) {
      // Set preferred orientations
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown
      ]);

      return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).primaryColor,
          title: Text(widget.name.toString()),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        extendBodyBehindAppBar: false,
        body: WebViewWidget(controller: controller),
      );
    }
        // Your widget content here
        );
  }
}
