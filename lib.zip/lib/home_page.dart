import 'dart:io';

import 'package:desktop_webview_window/desktop_webview_window.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get_storage/get_storage.dart';

import 'book_view.dart';
import 'dailogs/add_book.dart';
import 'dailogs/download_file.dart';
import 'dailogs/update_book.dart';
import 'database/google_sheets_database.dart';
import 'widgets/custom_text.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  static const String id = 'home-page';

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List books = [];
  getBooks() async {
    List books = await GoogleSheetsDatabase.get('books', '');
    setState(() {
      this.books = books;
    });
  }

  var box = GetStorage();
  var userId = '';
  var userData = {};
  getUserData() async {
    userId = box.read('userId');
    // var data = await GoogleSheetsDatabase.get('users', userId.toString());
    setState(() {
      // userData = data;
    });
  }

  @override
  void initState() {
    getBooks();
    getUserData();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator.adaptive(
      onRefresh: () {
        return getBooks();
      },
      child: Scaffold(
        appBar: AppBar(
          actions: [
            IconButton(
                onPressed: () async {
                  addBook(context);
                },
                icon: Icon(Icons.add_box)),
          ],
          backgroundColor: Theme.of(context).primaryColor,
          elevation: 0,
          centerTitle: true,
          title: const CustomText(
              text: "Library",
              fontFamily: 'MerriWeather',
              textColor: Colors.white,
              fontWeight: FontWeight.w800,
              fontStyle: FontStyle.normal,
              fontSize: 14.0),
        ),
        body: RefreshIndicator.adaptive(
          onRefresh: () {
            return getBooks();
          },
          child: SingleChildScrollView(
            child: ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: books.length,
              itemBuilder: (BuildContext context, int index) {
                var book = books[index];
                return Card(
                  child: ListTile(
                    onLongPress: () async {
                      updateBook(
                        context,
                        book,
                      );
                    },
                    onTap: () async {
                      if (Platform.isWindows) {
                        final webview = await WebviewWindow.create(
                            configuration: CreateConfiguration(
                          title: book['name'].toString().toString(),
                          titleBarHeight: 0,
                        ));
                        webview.launch(book['link'].toString());
                      } else {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => BooksView(
                                      link: book['link'].toString(),
                                      name: book['name'].toString(),
                                      type: 'pdf',
                                    )));
                      }
                    },
                    leading: Image.network(book['image'].toString()),
                    title: Text(
                      book['name'].toString(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text(
                      book['description'].toString(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: IconButton(
                        onPressed: () async {
                          EasyLoading.show(status: 'please wait...');
                          try {
                            downloadFile(book['downloadLink'].toString(),
                                book['name'].toString().replaceAll(' ', ''));
                          } catch (e) {
                            EasyLoading.showError(e.toString());
                          }
                        },
                        icon: Icon(
                          Icons.download,
                          color: Theme.of(context).primaryColor,
                        )),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
